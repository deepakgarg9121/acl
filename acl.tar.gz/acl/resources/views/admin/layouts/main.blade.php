@include('admin.layouts.slices.header')
@include('admin.layouts.slices.top')
@include('admin.layouts.slices.leftside')
		
@yield('content')
		
@include('admin.layouts.slices.footer')